# test




## Инструкция по запуску:
* Склонировать репозиторий: git clone https://github.com/IvSergey/test.git
* Зайти в папку с проектом
* Установить npm-зависимости: npm i
* После установки npm-пакетов запустить dev-server: npm run-script start
* Собрать проект: npm run-script build